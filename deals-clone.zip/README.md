# Deals Page Clone

A React + Tailwind clone of the Deals table UI with a slide-out "Create deal" drawer.

## Run locally

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually http://localhost:5173).

## Structure

- `src/App.jsx` — the whole page: sidebar, tabs, filter bar, table, pagination, and the right-side drawer.
- `src/main.jsx` — React entry point.
- `src/index.css` — Tailwind directives.
- `tailwind.config.js`, `postcss.config.js`, `vite.config.js` — build/tooling config.

## Notes

- Uses `lucide-react` for icons.
- Click any table row to open the drawer, pre-filled with that row's data (owner, deal name, stage, amount, dates). Click the X, "Cancel", or the overlay to close it.
- Row checkboxes are independent of the drawer click (stop propagation), so you can select rows without opening the drawer.
